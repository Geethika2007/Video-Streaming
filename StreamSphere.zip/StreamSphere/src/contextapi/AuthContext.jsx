import { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return sessionStorage.getItem('isLoggedIn') === 'true';
  });
  const [role, setRole] = useState(() => {
    return sessionStorage.getItem('role') || null;
  });

  useEffect(() => {
    sessionStorage.setItem('isLoggedIn', isLoggedIn);
    sessionStorage.setItem('role', role);
  }, [isLoggedIn, role]);

  const login = (token, userRole) => {
    sessionStorage.setItem('token', token);
    setIsLoggedIn(true); 
    setRole(userRole);
  };

  const logout = () => {
    sessionStorage.clear();
    setIsLoggedIn(false);
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ isLoggedIn, role, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
