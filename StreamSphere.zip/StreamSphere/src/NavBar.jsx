
import { useAuth } from './contextapi/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import NotificationsIcon from '@mui/icons-material/Notifications';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';

const NavBar = ({ setSideNavbarFunc, sideNavbar }) => {
  const { isLoggedIn, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="navbar">
      <div className="navbar-left">
        <div className="navbarHamberger" onClick={() => setSideNavbarFunc(!sideNavbar)}>
          <MenuIcon sx={{ color: 'white' }} />
        </div>
        <Link to="/" className="navbar_youtubeImg">StreamSphere</Link>
      </div>

      <div className="navbar-middle">
        <div className="navbar_searchBox">
          <input type="text" placeholder="Search" className="navbar_searchBoxInput" />
          <SearchIcon className="navbar_searchIconInside" />
        </div>
      </div>

      <div className="navbar-right">
        <NotificationsIcon className="notification-icon" />
        {isLoggedIn ? (
          <button onClick={handleLogout} className="signin-button">Logout</button>
        ) : (
          <Link to="/signin" className="signin-button">Sign In</Link>
        )}
      </div>
    </div>
  );
};

export default NavBar;
