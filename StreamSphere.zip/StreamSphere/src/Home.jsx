import React, { useEffect, useState } from 'react';
import axios from 'axios';
//import config from '../config'; // Adjust path if needed
import config from './config';
import './Style.css'; // Make sure it contains video-grid styles

const Home = () => {
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const res = await axios.get(`${config.url}/api/video/all`);
        setVideos(res.data);
      } catch (err) {
        console.error("Error fetching videos:", err);
      }
    };

    fetchVideos();
  }, []);

  return (
    <div className="home-page-public">
      <h2 style={{ color: 'white', marginBottom: '20px' }}>🎬 Public Videos</h2>
      {videos.length === 0 ? (
        <p style={{ color: 'gray' }}>No public videos found</p>
      ) : (
        <div className="video-grid">
          {videos.map((video) => (
            <div key={video.id} className="video-card">
              <video width="100%" height="180" controls>
                <source src={`${config.url}/api/video/${video.id}`} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              <h3>{video.title}</h3>
              <p>{video.description}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
