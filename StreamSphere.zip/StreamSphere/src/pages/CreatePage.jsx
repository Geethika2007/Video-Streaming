import React, { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';
import { useNavigate } from 'react-router-dom';
import './Auth.css';

const CreatePage = () => {
  const [channelExists, setChannelExists] = useState(false);
  const [channelName, setChannelName] = useState('');
  const [channelDesc, setChannelDesc] = useState('');
  const navigate = useNavigate();

  const [file, setFile] = useState(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const token = sessionStorage.getItem('token');

  // ✅ Check with backend if channel exists
  useEffect(() => {
    const fetchChannel = async () => {
      if (!token) return;

      try {
        const res = await axios.get(`${config.url}/api/channel/user/channel`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const channel = res.data;
        if (channel?.channelId || channel?.id) {
          const id = channel.channelId || channel.id;
          sessionStorage.setItem('channelId', id);
          setChannelExists(true);
        } else {
          setChannelExists(false);
        }
      } catch (err) {
        console.log('No channel found, show create form.');
        setChannelExists(false);
      }
    };

    fetchChannel();
  }, [token]);

  const handleCreateChannel = async (e) => {
    e.preventDefault();

    if (!token) {
      alert('User is not authenticated!');
      return;
    }

    try {
      const res = await axios.post(`${config.url}/api/channel/create`, null, {
        params: {
          name: channelName,
          description: channelDesc,
        },
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const newChannelId = res?.data?.channelId || res?.data?.id;
      if (!newChannelId) {
        alert('❌ Failed to receive channel ID from backend.');
        return;
      }

      sessionStorage.setItem('channelId', newChannelId);
      setChannelExists(true);
      alert('✅ Channel created successfully!');
    } catch (err) {
      console.error(err);
      alert('❌ Channel creation failed');
    }
  };

  const handleUploadVideo = async (e) => {
    e.preventDefault();

    const channelId = sessionStorage.getItem('channelId');

    if (!token || !channelId || channelId === 'undefined') {
      alert('❗ You must create a channel before uploading.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title);
    formData.append('description', description);
    formData.append('channelId', channelId);

    try {
      await axios.post(`${config.url}/api/video/upload`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      });

      alert('🎉 Video uploaded successfully!');
      setFile(null);
      setTitle('');
      setDescription('');
      navigate('/myvideos');
    } catch (err) {
      console.error(err);
      const errMsg = err?.response?.data || err.message || '[unknown error]';
      alert(`🚫 Video upload failed: ${errMsg}`);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-container">
        {channelExists ? (
          <>
            <h2>Upload Video</h2>
            <form onSubmit={handleUploadVideo}>
              <input
                type="file"
                accept="video/*"
                onChange={(e) => setFile(e.target.files[0])}
                required
              />
              <input
                type="text"
                placeholder="Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
              <textarea
                placeholder="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
              <button type="submit" className="upload-button">Upload</button>
            </form>
          </>
        ) : (
          <>
            <h2>Create Your Channel</h2>
            <form onSubmit={handleCreateChannel}>
              <input
                type="text"
                placeholder="Channel Name"
                value={channelName}
                onChange={(e) => setChannelName(e.target.value)}
                required
              />
              <textarea
                placeholder="Channel Description"
                value={channelDesc}
                onChange={(e) => setChannelDesc(e.target.value)}
                required
              />
              <button type="submit" className="upload-button">Create Channel</button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default CreatePage;
