import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../config';
import './MyVideos.css'; // new CSS file for better layout and styling

const MyVideos = () => {
  const [videos, setVideos] = useState([]);
  const channelId = sessionStorage.getItem('channelId');
  const token = sessionStorage.getItem('token');

  useEffect(() => {
    const fetchVideos = async () => {
      if (!channelId || !token) {
        alert('Not authenticated or channel ID missing!');
        return;
      }

      try {
        const res = await axios.get(`${config.url}/api/channel/${channelId}/videos`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setVideos(res.data);
      } catch (err) {
        console.error(err);
        alert('❌ Failed to fetch videos');
      }
    };

    fetchVideos();
  }, [channelId, token]);

  const handleDelete = async (videoId) => {
    try {
      await axios.delete(`${config.url}/api/video/${videoId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setVideos(videos.filter((v) => v.id !== videoId));
      alert('✅ Video deleted successfully');
    } catch (err) {
      console.error(err);
      alert('❌ Failed to delete video');
    }
  };

  return (
    <div className="video-grid">
      {videos.length === 0 ? (
        <p className="no-videos">No videos found 🎬</p>
      ) : (
        videos.map((video) => (
          <div key={video.id} className="video-card">
            <video width="100%" height="180" controls>
              <source src={`${config.url}/api/video/${video.id}`} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <h3>{video.title}</h3>
            <p>{video.description}</p>
            <button className="delete-button" onClick={() => handleDelete(video.id)}>🗑️ Delete</button>
          </div>
        ))
      )}
    </div>
  );
};

export default MyVideos;
