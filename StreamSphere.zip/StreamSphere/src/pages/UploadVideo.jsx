import React, { useState } from 'react';
import axios from 'axios';
import config from '../config'; // Ensure this has your backend URL
import './Auth.css'; // Optional: reuse your auth form styles

const UploadVideo = () => {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleUpload = async (e) => {
    e.preventDefault();

    const channelId = sessionStorage.getItem('channelId');
    const token = sessionStorage.getItem('token');

    if (!channelId || !token) {
      alert('User is not authenticated or channel not found!');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title);
    formData.append('description', description);
    formData.append('channelId', channelId);

    try {
      const response = await axios.post(`${config.url}/api/video/upload`, formData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      });

      alert('🎉 Video uploaded successfully');
      console.log(response.data);
      // Clear fields
      setFile(null);
      setTitle('');
      setDescription('');
    } catch (err) {
      console.error(err);
      alert('🚫 Upload failed. Please try again.');
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-container">
        <h2>Upload Video</h2>

        <form onSubmit={handleUpload}>
          <input
            type="file"
            accept="video/*"
            onChange={(e) => setFile(e.target.files[0])}
            required
          />
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          <button type="submit" className="upload-button">Upload</button>
        </form>
      </div>
    </div>
  );
};

export default UploadVideo;
