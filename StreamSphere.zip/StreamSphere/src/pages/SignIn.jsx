import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../config';
import { useAuth } from '../contextapi/AuthContext';
import './Auth.css';

const SignIn = () => {
  const [emailId, setEmailId] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const { isLoggedIn, login } = useAuth();

  useEffect(() => {
    if (isLoggedIn) {
      navigate('/dashboard');
    }
  }, [isLoggedIn, navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${config.url}/api/auth/login`, {
        emailId,
        password,
      });

      const { token, role } = response.data;

      login(token, role); // Save token and role via context
      sessionStorage.setItem('token', token);
      sessionStorage.setItem('role', role);

      // 🔽 Fetch and store user's channel ID
      try {
        const channelRes = await axios.get(`${config.url}/api/channel/user/channel`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const channelId = channelRes.data?.channelId || channelRes.data?.id;
        if (channelId) {
          sessionStorage.setItem('channelId', channelId);
          console.log("✅ Channel ID stored:", channelId);
        } else {
          console.warn("⚠️ Channel not found for this user.");
        }
      } catch (channelErr) {
        console.error("❌ Error fetching user's channel:", channelErr);
      }

      alert('✅ Login successful!');
      navigate('/dashboard');
    } catch (err) {
      if (err.response?.status === 401) {
        alert('❌ Invalid credentials');
      } else {
        alert('💥 Server error during login');
      }
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-container">
        <h2>Sign In</h2>
        <form onSubmit={handleLogin}>
          <input
            type="email"
            placeholder="Email"
            value={emailId}
            onChange={(e) => setEmailId(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit">Login</button>
          <p>
            Don't have an account? <a href="/signup">Sign Up</a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default SignIn;
