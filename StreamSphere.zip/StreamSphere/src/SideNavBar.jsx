import React from 'react';
import { Link, useNavigate } from 'react-router-dom'; // 👈 also import useNavigate
import './Style.css';

import DashboardIcon from '@mui/icons-material/Dashboard';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import HistoryIcon from '@mui/icons-material/History';
import WhatshotIcon from '@mui/icons-material/Whatshot';
import VideoLibraryIcon from '@mui/icons-material/VideoLibrary';
import AddBoxIcon from '@mui/icons-material/AddBox';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import FeedbackOutlinedIcon from '@mui/icons-material/FeedbackOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';

const SideNavBar = ({ sideNavbar }) => {
  const navigate = useNavigate();



  return (
    <div className={sideNavbar ? 'vistro-sideNavbar' : 'vistro-sideNavbarHide'}>
      <div className="nav-section">
        <h4 className="nav-title">Vistro Navigation</h4>

        <Link to="/" className="nav-item">
          <DashboardIcon /><span>Dashboard</span>
        </Link>

        <Link to="/subscriptions" className="nav-item">
          <SubscriptionsIcon /><span>Subscriptions</span>
        </Link>

        <Link to="/bookmarks" className="nav-item">
          <BookmarkIcon /><span>Bookmarks</span>
        </Link>

        <Link to="/favourites" className="nav-item">
          <FavoriteBorderIcon /><span>Favourites</span>
        </Link>

        <Link to="/history" className="nav-item">
          <HistoryIcon /><span>History</span>
        </Link>

        <Link to="/trending" className="nav-item">
          <WhatshotIcon /><span>Trending</span>
        </Link>

        <Link to="/myvideos" className="nav-item">
          <VideoLibraryIcon /><span>My Videos</span>
        </Link>

        <Link to="/create" className="nav-item">
          <AddBoxIcon /><span>Create</span>
        </Link>
      </div>

      <div className="nav-section">
        <h4 className="nav-title">More from StreamSphere</h4>

        <Link to="/help" className="nav-item">
          <HelpOutlineIcon /><span>Help</span>
        </Link>

        <Link to="/feedback" className="nav-item">
          <FeedbackOutlinedIcon /><span>Feedback</span>
        </Link>

        <Link to="/settings" className="nav-item">
          <SettingsOutlinedIcon /><span>Settings</span>
        </Link>
      </div>


    </div>
  );
};

export default SideNavBar;