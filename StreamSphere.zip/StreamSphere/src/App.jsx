import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


import { useAuth } from './contextapi/AuthContext';

import NavBar from './NavBar';
import SideNavBar from './SideNavBar';
import Home from './Home';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';
import PrivateRoute from './components/PrivateRoute';
import MyVideos from './pages/MyVideos';
import CreatePage from './pages/CreatePage';
import './Style.css';

function App() {
  const [sideNavbar, setSideNavbar] = useState(true);
  const { isLoggedIn } = useAuth();
  return (
    <BrowserRouter>
      <div className="fullHomePage">
        <NavBar setSideNavbarFunc={setSideNavbar} sideNavbar={sideNavbar} />
        <div className="home">
          <SideNavBar sideNavbar={sideNavbar} />
          <div className="main-content">
            <Routes>
              {/* 🟢 Public route – visible to all */}
              <Route path="/" element={<Home />} />
              <Route path="/create" element={<CreatePage />} />
              {/* <Route path="/upload" element={<UploadVideo />} /> */}
              {/* 🔐 Protected route – only after login */}
              <Route path="/dashboard" element={
                <PrivateRoute>
                  <Home />
                </PrivateRoute>
              } />

        <Route path="/signin" element={isLoggedIn ? <Navigate to="/dashboard" /> : <SignIn />} />

              <Route path="/signup" element={<SignUp />} />
              <Route path="/myvideos" element={
                <PrivateRoute>
                  <MyVideos />
                </PrivateRoute>
              } />
            </Routes>
            <ToastContainer position="top-center" autoClose={1500} />
          </div>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
